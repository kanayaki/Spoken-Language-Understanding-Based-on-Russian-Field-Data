# этот скрипт для того чтобы заполнять поле entities
# по размеченному text_annotation
# и еще в конце он '[это]' превращает в '[ это ]'
# в этом скрипте необходимо раскомментировать и заполнить 2 переменные

import json
import re

# в переменную file_path ввести путь к файлу, из которого читаем
# file_path = '<...>'

with open(file_path, 'r', encoding='utf-8') as file:
    data = json.load(file)


def tokenize(text):
    return re.findall(r"\w+", text)

l = []


for item in data:
    text = item["text"]
    annotation = item["text_annotation"]

    tokens = tokenize(text)
    tokens_norm = [t.lower() for t in tokens]

    pattern = re.findall(r"\[(.*?)\s*:\s*(.*?)\]", annotation)

    entities = []
    cursor = 0
    used = [False] * len(tokens)

    for ent_type, ent_value in pattern:
        words = tokenize(ent_value)
        words_norm = [w.lower() for w in words]
        found = False

        for i in range(cursor, len(tokens)):
            if tokens_norm[i:i+len(words_norm)] == words_norm:
                span = list(range(i, i + len(words)))
                for j in span:
                    used[j] = True

                entities.append({
                    "type": ent_type.strip(),
                    "span": span
                })

                cursor = i + len(words)
                found = True
                break

        if not found:
            for i in range(len(tokens)):
                if not used[i] and tokens_norm[i:i+len(words_norm)] == words_norm:
                    span = list(range(i, i + len(words)))
                    for j in span:
                        used[j] = True

                    entities.append({
                        "type": ent_type.strip(),
                        "span": span
                    })

                    found = True
                    break

        if not found:
            entities.append({
                "type": ent_type.strip(),
                "span": []
            })

    item['entities'] = entities
    item["text_annotation"] = re.sub(r'\[', '[ ', item["text_annotation"])
    item["text_annotation"] = re.sub(r'\]', ' ]', item["text_annotation"])
    l.append(item)

# это нужно чтобы все визуально красиво выводилось в джейсоне
for item in l:
    for e in item.get("entities", []):
        e["_span_json"] = json.dumps(e["span"], ensure_ascii=False)
        del e["span"]

# в переменную file_path ввести путь к файлу, в который записываем
# file_path = '<...>'
with open(file_path, 'w', encoding='utf-8') as json_file:
    json_str = json.dumps(l, indent=2, ensure_ascii=False)
    json_str = re.sub(r'"_span_json": ("(\[.*?\])")', lambda m: f'"span": {m.group(2)}', json_str)
    json_file.write(json_str)