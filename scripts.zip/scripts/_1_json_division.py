# этот скрипт для того чтобы убрать повторы из большого файла с разметкой и разбить его на много мелких
# один файл - один разговор
# в этом скрипте необходимо раскомментировать и заполнить 2 переменные

import json

def json_create(item_name, current_list):
    c = 1
    for i in range(len(current_list)):
        current_list[i] = {'id': c, **current_list[i]}
        current_list[i]['text'] = current_list[i]['text'].replace('[', '<').replace(']', '>')
        current_list[i]['text_annotation'] = current_list[i]['text']
        current_list[i]['entities'] = [{'type': '', 'span': []}]
        current_list[i]['function'] = ['']
        c += 1

    # в переменную file_path вместо <...> ввести путь к папке, в которую записываем
    # file_path = f'<...>/{item_name}.json'
    with open(file_path, 'w', encoding='utf-8') as json_file:
        json.dump(current_list, json_file, indent=2, ensure_ascii=False)


# в переменную file_path ввести путь к файлу, из которого читаем
# file_path = '<...>'

with open(file_path, 'r', encoding='utf-8') as file:
    data = json.load(file)

group_list = []
group_set = set()
current_group = ''

for item in data:
    current_item = "-".join(item['audio_filepath'][6:].rsplit(".", 1)[0].split("-")[:-2])
    if current_item != current_group:
        # создаем json с current_group
        if len(group_list) > 0:
            json_create(current_group, group_list)

        # создаем новую группу
        current_group = current_item
        group_list = []
        group_set = set()
        group_list.append(item)
        group_set.add(item['audio_filepath'] + ' ' + item['text'])

    else:
        if (item['audio_filepath'] + ' ' + item['text']) not in group_set:
            group_list.append(item)
            group_set.add(item['audio_filepath'] + ' ' + item['text'])

json_create(current_group, group_list)