# заполняем поля говорящего, стираем ненужное для интервьюера и делаем, чтобы спан был записан красиво
# в этом скрипте необходимо раскомментировать и заполнить 4 переменные

import json
import re

# в переменную file_path ввести путь к файлу, из которого читаем
# file_path = '<...>'

with open(file_path, 'r', encoding='utf-8') as file:
    data = json.load(file)

for i in range(len(data)):
    if data[i]['speaker_id'] == 'U_unknown_unknown':
        # в переменную data[i]['speaker_id'] ввести id спикера
        # data[i]['speaker_id'] = '<...>'
        # в переменную data[i]['native_language'] ввести родной язык спикера
        # data[i]['native_language'] = '<...>'

    elif data[i]['speaker_id'] == 'interviewer':
        data[i]['language'] = ''
        data[i]['native_language'] = ''
        data[i]['text_annotation'] = ''
        data[i]['entities'] = []
        data[i]['function'] = []

# это нужно чтобы все визуально красиво выводилось в джейсоне
for item in data:
    for e in item.get("entities", []):
        e["_span_json"] = json.dumps(e["span"], ensure_ascii=False)
        del e["span"]

# в переменную file_path ввести путь к файлу, в который записываем
# file_path = '<...>'
with open(file_path, 'w', encoding='utf-8') as json_file:
    json_str = json.dumps(data, indent=2, ensure_ascii=False)
    json_str = re.sub(r'"_span_json": ("(\[.*?\])")', lambda m: f'"span": {m.group(2)}', json_str)
    json_file.write(json_str)